function fizzBuzz(start,end){
    
    if(start==null&&end==null){
        start = 74;
        end = 291; 
        for(var i=1;i<=100;i++){  
            if((i%3)==0&&(i%5)!=0)  
                console.log('buzz');  
            if((i%5)==0&&(i%3)!=0)  
                console.log('fizz');  
            if(i%15==0)  
                console.log('buzzfizz');  
            else  
                console.log(i);  
        }  
    }if(start<end&&typeof start=="number" &&typeof end=="number"){
        for(var i=start;i<=end;i++){  
            if((i%3)==0&&(i%5)!=0)  
                console.log('buzz');  
            if((i%5)==0&&(i%3)!=0)  
                console.log('fizz');  
            if(i%15==0)  
                console.log('buzzfizz');  
            else  
                console.log(i);  
        }  
    }else{
        throw "input arguments must be number and start number need to samll than end number";
    }
}

fizzBuzz(null,null);
//if you want to add some arguments
//fizzBuzz(1,100);

