const fs = require('fs');
const path = require('path');
const readline = require('readline');
const playerLetters = ['X', 'O', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'Y', 'Z'];
const game = readline.createInterface(process.stdin, process.stdout);

var config = {
    playerNum: 2,
    boardSize: 3,
    row: 3,
    col: 3,
    winConfig: 3,
    currentPlayer: 0,
    double: false,
    totalStep: []
};
var current = {
    currentPlayer: 0,
    col: 0,
    row: 0
}

main();

function StartGameQuestions() {
    game.question('Resume a saved game? (Y/N)\n', saved_game => {
        saved_game = saved_game.toUpperCase();
        if (saved_game === 'YES' || saved_game === 'Y') {
            console.log('\nYou picked a saved game.\n');
            //console.log('what')
            game.question('what type of the game you want to resume? (txt/xml)\n', data => {
                if (data.toLowerCase() == 'txt') {
                    console.log('\nYou picked a txt saved game.\n');
                    LoadGame(game);
                } else if (data.toLowerCase() == 'xml') {
                    console.log('\nYou picked a xml saved game.\n');
                    LoadGame(game);
                } else {
                    console.log('Not valid.');
                    StartGameQuestions();
                }
            })
            LoadGame(game);

        }
        else if (saved_game === 'NO' || saved_game === 'N') {
            console.log('You start a new game.');
            config.double = false;
            game.question('How many players? (Maximum 26): ', players => {
                if (players <= 26 && players >= 2) {
                    config.playerNum = parseInt(players);
                    console.log(players);
                    game.question('How large is the board? (Maximum:999): ', board_size => {
                        //console.log(board_size.split(" "));
                        let row = parseInt(board_size.split(" ")[0]);
                        let col = parseInt(board_size.split(" ")[1]);
                        //console.log(row, col);
                        //console.log(typeof row);
                        if (board_size <= 999 || row * col <= 999) {
                            if (board_size >= 3 || (row * col >= 9)) {
                                config.boardSize = parseInt(board_size);
                                config.row = row;
                                config.col = col;
                                if (row && col) {
                                    config.double = true;
                                }
                                //console.log(board_size);
                                game.question('Win sequence count? ', winConfig => {
                                    if (parseInt(winConfig) > 0 && parseInt(winConfig) <= (row * col ? row * col : parseInt(board_size))) {
                                        if (((row * col) ? (row * col) : (board_size * board_size)) / winConfig >= players - 1) {
                                            console.log(winConfig);
                                            config.winConfig = parseInt(winConfig);
                                            beginGame(config);
                                        } else {
                                            console.log('nobody can win, result.board_num/result.sequence_count >= result.player - 1');
                                            StartGameQuestions();
                                        }

                                    }
                                    else {
                                        console.log('you input argument is wrong, no one can win');
                                        StartGameQuestions();
                                    }
                                })
                            } else {
                                console.log('boardSize is too small, cannot play game');
                                StartGameQuestions();
                            }
                        }
                        else {
                            console.log(`${board_size} need to be a number or small than 999`);
                            StartGameQuestions();
                        }
                    })
                }
                else {
                    console.log(`${players} is not enough or too much, players input another number`);
                    StartGameQuestions();
                }
            })
        }
        else {
            console.log('Not valid.');
            StartGameQuestions();
        }
    })
}

const drawBoard = (board_size, data) => {
    var board = '';
    if (data.double == true) {
        for (let x = 1; x <= data.row; x++) {
            if (x === 1) {
                board += '    ' + x;
            }
            else {
                board += '   ' + x;
            }
        }

        for (let row = 1; row <=  data.row; row++) {
            board += '\n' + row + '     ';

            for (var column = 1; column < data.col; column++) {
                board += '|   ';
            }
            board += '\n   ';

            if (row < data.row) {
                for (var row_col = 0; row_col < (data.row * 2 - 1); row_col++) {
                    if (row_col % 2 !== 0) {
                        board += '+';
                    }
                    else {
                        board += '---';
                    }
                }
            }
        }
        return board;
    } else {
        for (let x = 1; x <= board_size; x++) {
            if (x === 1) {
                board += '    ' + x;
            }
            else {
                board += '   ' + x;
            }
        }

        for (let row = 1; row <= board_size; row++) {
            board += '\n' + row + '     ';

            for (var column = 1; column < board_size; column++) {
                board += '|   ';
            }
            board += '\n   ';

            if (row < board_size) {
                for (var row_col = 0; row_col < (board_size * 2 - 1); row_col++) {
                    if (row_col % 2 !== 0) {
                        board += '+';
                    }
                    else {
                        board += '---';
                    }
                }
            }
        }
        return board;
    }

};



var LoadSavedGame = function (rl, dir, file) {


    fs.readFile(path.join(dir, file + ".xml"), (err, data) => {
        if (err) {
            console.error("Error, choose a different save, this has something wrong", err);
        }
        else {
            MyCrumbyXmlParser(data.toString());
        }
    })

}

var LoadSavedGameTxt = function (rl, dir, file) {


    fs.readFile(path.join(dir, file + ".txt"), 'utf-8', (err, data) => {
        if (err) {
            console.error("Error, choose a different save, this has something wrong", err);
        }
        else {
            try {
                console.log('--------');
                console.log(JSON.parse(data.size));
                MyCrumbyTxtParser(data.toString());
            } catch (e) {
                console.log('--------');
                let gamedata = JSON.parse(data);
                // var config = {
                //     playerNum: 2,
                //     boardSize: 3,
                //     winConfig: 3,
                //     currentPlayer: 0
                // };
                let { playerNum, boardSize, winConfig, currentPlayer } = gamedata;
                //console.log(gamedata);
                console.log(playerNum, boardSize, winConfig, currentPlayer);
                beginGame(gamedata, 1, gamedata);
            }
        }
    })

}

var MyCrumbyXmlParser = function (xmlString) {
    var aSave = [];
    aSave["players"] = xmlString.substring(xmlString.indexOf("<players>") + 9, xmlString.indexOf("</players>"));
    aSave["boardSize"] = xmlString.substring(xmlString.indexOf("<boardSize>") + 11, xmlString.indexOf("</boardSize>"));//-xmlString.indexOf("<boardSize>")-1);
    aSave["winConfig"] = xmlString.substring(xmlString.indexOf("<winConfig>") + 13, xmlString.indexOf("</winConfig>"));//-xmlString.indexOf("<winConfig>")-1);

    beginGame(aSave);
}

var MyCrumbyTxtParser = function (xmlString) {
    var aSave = [];
    try {

    } catch (e) {
        console.log(error);
    }

    beginGame(aSave);
}

function LoadGame(rl) {

    game.question("Enter your save file name " +
        "\nyou do not need to enter the extension of the file,just file name.(like 1.txt,just input 1) \n" +
        "\nor type Exit or e to return to the menu... \n", resp => {

            if (resp.toLowerCase() == 'exit' || resp == 'e') {
                console.log('return main board');
                StartGameQuestions();
            } else {
                // LoadSavedGame(rl, __dirname, resp);
                LoadSavedGameTxt(rl, __dirname, resp);
            }
        })
}


var activeBoard = [];

function beginGame(settings, resume, resumedata) {
    if (resume) {
        console.log('-----Game Started-----');
        //activeBoard = createMatrix(settings.boardSize);
        //drawBoard(settings.boardSize);
        activeBoard = settings.size;
        console.log(activeBoard);
        recursiveAsyncReadLine(activeBoard, resumedata);
    } else {
        console.log('-----Game Started-----');
        activeBoard = createMatrix(config.boardSize, config);
        board = drawBoard(config.boardSize, config);
        console.log(board);
        recursiveAsyncReadLine(activeBoard);
    }
}

const createMatrix = (board_size,data) => {
    let matrix = [];
    if(data.double==true){
        for (let i = 0; i < data.row; i++) {
            let row = [];
            for (let j = 0; j < data.col; j++) {
                row.push(' ');
            }
            matrix.push(row);
        }
    }else{
        for (let i = 0; i < board_size; i++) {
            let row = [];
            for (let j = 0; j < board_size; j++) {
                row.push(' ');
            }
            matrix.push(row);
        }
    }
    

    console.log(matrix);
    config.totalStep = matrix;
    return matrix;
};

const playerMoved = (row, column, value, current) => {
    console.log(row, column, value);
    if (activeBoard[row][column] === ' ') {
        console.log('player has moved');
        activeBoard[row][column] = value;
        console.log(activeBoard);
        config.totalStep = activeBoard;
    } else {
        throw 'a player exists in that space, choose another place';
    }
    checkForWinner(activeBoard, value, current);
}

const recursiveAsyncReadLine = (board, saveData) => {

    if (saveData) {
        config.currentPlayer = saveData.currentPlayer;
        config.playerNum = saveData.playerNum;
        config.winConfig = saveData.winConfig;
        if (config.currentPlayer >= config.playerNum) {
            config.currentPlayer = 0;
        }
    } else {
        if (config.currentPlayer >= config.playerNum) {
            config.currentPlayer = 0;
        }
    }
    const row = board.length;
    const col = board[0].length;
    // console.log(row,col);
    game.question('Enter a row column format(3 2) \ntype save to save the game \ninput end or quit to end the game \n', function (answer) {

        if (answer.toLowerCase() == 'save' || answer.toLowerCase() == 's') {
            game.question('which type you want to save (txt or xml)', (data) => {
                if (data.toLowerCase() == 'txt') {
                    game.question('input the name of the file\n', (name) => {
                        if (name) {
                            let gameData = { size: board, currentPlayer: config.currentPlayer, winConfig: config.winConfig, playerNum: config.playerNum, boardSize: config.boardSize }
                            saveGameTxt(name, JSON.stringify(gameData));
                            return game.close();
                        } else {
                            console.log('you need to input filename');
                            return game.close();
                        }
                    })

                } else if (data.toLowerCase() == 'xml') {
                    saveGameXml();
                    return game.close();
                } else {
                    return game.close();
                }
            })
        }
        if (answer == 'end' || answer == 'e' || answer == 'quit' || answer == 'q') {
            console.log('game end');
            return game.close();
        }
        let grid = answer.split(' ');
        //console.log(parseInt(grid[0]));
        if (parseInt(grid[0]) && parseInt(grid[1]) && parseInt(grid[0]) <= row && parseInt(grid[1]) <= col) {

            console.log('Your answer was:  ' + answer + '  "', playerLetters[config.currentPlayer], '"');

            current.col = parseInt(grid[0]) - 1;
            current.row = parseInt(grid[1]) - 1;
            current.currentPlayer = playerLetters[config.currentPlayer];
            playerMoved((parseInt(grid[0]) - 1), parseInt((grid[1]) - 1), playerLetters[config.currentPlayer], current);

            config.currentPlayer++;
            recursiveAsyncReadLine(board);


        } else {
            console.log('input is not valid, try again');
            //return game.close();
            recursiveAsyncReadLine(board);
        }
    });
};

const checkForWinner = (board, player, current) => {
    let maxContinuousDiaStep = 1;
    if (checkRows(board, player) || checkDiagonals(board, player) || checkColumns(board, player) || checkDiagonal(board, board.length, board[0].length, player, maxContinuousDiaStep, current)) {
        console.log(`${player} user has won`);
        game.question('end or start game? (Y/N)\n', (data) => {
            if (data.toLowerCase() == 'y' || data.toLowerCase() == 'yes') {

                StartGameQuestions();
            } else {
                console.log('game is end');
                game.close();
            }
        })

    } else if (checkTie(board)) {
        console.log('is a tie game');
        game.question('end or start game? (Y/N)\n', (data) => {
            if (data.toLowerCase() == 'y' || data.toLowerCase() == 'yes') {

                StartGameQuestions();
            } else {
                console.log('game is end');
                game.close();
            }
        })
    } else {
        console.log('not a winner');
    }
}

const checkRows = (board, player) => {
    var win = false;
    for (var r = 0; r < board.length; r++) {
        var rowSum = 1;
        var previousVal = 'start';
        for (var t = 0; t < board[r].length; t++) {
            if (board[r][t] === player) {
                ++rowSum;
                if (previousVal !== board[r][t] && rowSum > 2) {
                    rowSum = 0;
                }
            }
            previousVal = board[r][t];
            if (rowSum > config.winConfig) {
                win = true;
                break;
            }
        }
    }
    return win;
}

const checkTie = (board) => {
    let count = 0;
    if (board) {
        for (let i = 0; i < board.length; i++) {
            for (let j = 0; j < board[0].length; j++) {
                if (board[i][j] == ' ') {
                    count++;
                }
            }
        }
        if (count == 0) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

const checkDiagonal = (board, x, y, player, maxContinuousDiaStep, current) => {
    // var i = x - 1;
    // var j = y - 1;
    //console.log('+++++++++++++++');
    console.log(current);
    // console.log(x,y);
    // console.log(i,j);
    var i = current.row - 1;
    var j = current.col - 1;
    while (i >= 0 && j >= 0 && board[i][j] == player) {
        maxContinuousDiaStep++;
        i--;
        j--;
    }
    // var m = x + 1;
    // var n = y + 1;
    var m = current.row + 1;
    var n = current.col + 1;
    while (m < config.boardSize && n << config.boardSize && board[m][n] == player) {
        maxContinuousDiaStep++;
        m++;
        n++;
    }
    if (maxContinuousDiaStep >= config.winConfig) {
        return true;
    } else {
        return false;
    }
}

function checkDiagonals(board, player) {
    let win = false;
    try {
        for (let r = 0; r < board.length; r++) {
            let rowSum = 0;
            let previousVal = 'start';
            //console.log(board);
            for (let t = 0; t < board[r].length; t++) {
                if (board[r][t] === player) {
                    ++rowSum;
                }
                if (board[r + 1]) {
                    if (board[r + 1][t + 1] === player) {
                        rowSum = frontDiagonal(r, t, board, rowSum, player);
                        if (rowSum >= config.winConfig) {
                            win = true;
                            break;
                        }
                    }
                }
                if (board[r + 1]) {
                    if (board[r + 1][t - 1] === player) {
                        rowSum = backDiagonal(r, t, board, rowSum, player);
                        if (rowSum >= config.winConfig) {
                            win = true;
                            break;
                        }
                    }
                }

                // if (board[r + 1][t - 1] || board[r + 1][t + 1]) {
                //     if (board[r][t] == player || board[r + 1][t + 1] == player) {
                //         ++rowSum;
                //     }
                // }
                // if (board[r - 1][t - 1] || board[r - 1][t + 1]) {
                //     if (board[r - 1][t] == player || board[r - 1][t + 1] == player) {
                //         ++rowSum;
                //     }
                // }
                previousVal = board[r][t];
                if (rowSum >= config.winConfig) {
                    win = true;
                    break;
                }
            }
        }
        return win;
    } catch (e) {
        return false;
    }

}

const backDiagonal = (i, j, arr, result, player) => {

    if (arr[i + 1]) {
        if (arr[i + 1][j - 1] == player) {
            ++result;
            backDiagonal(i + 1, j - 1, arr, result);
        } else {
            return result;
        }
    }
}

const frontDiagonal = (i, j, arr, result, player) => {
    if (arr[i + 1]) {
        if (arr[i + 1][j + 1] == player) {
            ++result;
            frontDiagonal(i + 1, j + 1, arr, result);
        } else {
            return result;
        }
    }
}

function checkColumns(board, player) {
    function transpose(a) {
        return Object.keys(a[0]).map(
            function (c) { return a.map(function (r) { return r[c]; }); }
        );
    }

    return checkRows(transpose(board), player);
}


const saveGameTxt = (file, data) => {
    fs.writeFile(path.join(__dirname, file + ".txt"), data, { encoding: 'utf8', mode: 438 /*=0666*/, flag: 'w' }, (err, data) => {
        if (err) {
            console.log('some argument is wrong, please try again');
        } else {
            console.log('save success');
        }
    })
}

const saveGameXml = (file, data) => {
    fs.writeFile(path.join(__dirname, file + ".xml"), data, { encoding: 'utf8', mode: 438 /*=0666*/, flag: 'w' }, (err, data) => {
        if (err) {
            console.log('some argument is wrong, please try again');
        } else {
            console.log('save success');
        }
    })
}


function main() {
    console.log('Tic-Tac-Toe');
    console.log(
        '                  |   |   \n' +
        '               ---+---+--- \n' +
        '                  |   |   \n' +
        '               ---+---+--- \n' +
        '                  |   |   \n');

    StartGameQuestions();
}